//
//  ViewController.swift
//  MfirstFirebase
//
//  Created by Lola M on 12/6/21.
//

import UIKit
import Firebase

class ViewController: UIViewController {
        
    @IBOutlet weak var Label: UILabel!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passTF: UITextField!
    @IBOutlet weak var btnOutlet: UIButton!
    @IBOutlet weak var phoneBtnOutlet: UIButton!
    @IBOutlet weak var gmailOutlet: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Styling
        Label.textColor = .systemPink
        Label.textAlignment = .left
        emailTF.textColor = .black
        passTF.textColor = .black
        btnOutlet.tintColor = .systemPink
        phoneBtnOutlet.tintColor = .systemYellow
        phoneBtnOutlet.titleLabel?.textColor = .black
        gmailOutlet.tintColor = .purple
    }

    @IBAction func btnAction(_ sender: Any) {
        Auth.auth().createUser(withEmail: emailTF.text!, password: passTF.text!) { user, error in
            if error == nil {
                print(user?.user.uid)
                self.dismiss(animated: true, completion: nil)
            } else {
                print(error!)
            }
        }
    }
    
    @IBAction func phoneBtnAction(_ sender: Any) {
        performSegue(withIdentifier: "phoneToEnterPhone", sender: self)
    }
    
    
    @IBAction func gmailAction(_ sender: Any) {
        print("Google Login")
    }
}

