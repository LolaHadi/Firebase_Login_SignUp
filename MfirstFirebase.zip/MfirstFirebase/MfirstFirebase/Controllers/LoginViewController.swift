//
//  LoginViewController.swift
//  MfirstFirebase
//
//  Created by Lola M on 12/6/21.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {

    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passTF: UITextField!
    @IBOutlet weak var NewOutlet: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NewOutlet.titleLabel?.textAlignment = .right
        passTF.isSecureTextEntry = true
    }
    
    @IBAction func SigninBtnAction(_ sender: Any) {
        Auth.auth().signIn(withEmail: emailTF.text!, password: passTF.text!) { user, error in
            if error == nil {
                self.performSegue(withIdentifier: "loginToHome", sender: self)
            } else {
                print(error!)
            }
        }
        
    }
    
    
    @IBAction func NewAction(_ sender: Any) {
        
        performSegue(withIdentifier: "newToSignup", sender: self)
    }
}
