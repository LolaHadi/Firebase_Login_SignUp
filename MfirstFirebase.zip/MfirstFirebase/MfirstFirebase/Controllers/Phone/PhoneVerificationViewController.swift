//
//  PhoneVerificationViewController.swift
//  MfirstFirebase
//
//  Created by Lola M on 12/6/21.
//

import UIKit
import Firebase

class PhoneVerificationViewController: UIViewController {
    
    var codeID: String?
    
    @IBOutlet var tf: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func signupAction(_ sender: Any) {
        let codeSms = PhoneAuthProvider.provider().credential(withVerificationID: codeID!, verificationCode: tf.text!)
        
        Auth.auth().signIn(with: codeSms) { user, error in
            if error == nil {
                let vc = CheckLoginSignupViewController()
                self.present(vc, animated: true, completion: nil)
            }
        }
    }
    
}
