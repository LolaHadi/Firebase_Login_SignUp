//
//  EnterPhoneViewController.swift
//  MfirstFirebase
//
//  Created by Lola M on 12/6/21.
//

import UIKit
import Firebase

class EnterPhoneViewController: UIViewController {

    var smsID: String?
    
    @IBOutlet weak var tf: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func goAction(_ sender: Any) {
        PhoneAuthProvider.provider().verifyPhoneNumber(tf.text!, uiDelegate: nil) { idCode, error in
            if error == nil {
                self.smsID = idCode
                self.performSegue(withIdentifier: "EnterPhoneToCodeVerification", sender: self)
            }
        }
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "EnterPhoneToCodeVerification" {
            let vc = PhoneVerificationViewController()
            vc.codeID = smsID
            
        }
    }
    
}
