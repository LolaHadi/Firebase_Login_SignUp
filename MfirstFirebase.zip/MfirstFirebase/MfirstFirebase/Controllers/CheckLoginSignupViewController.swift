//
//  CheckLoginSignupViewController.swift
//  MfirstFirebase
//
//  Created by Lola M on 12/6/21.
//

import UIKit
import Firebase

class CheckLoginSignupViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if Auth.auth().currentUser?.uid != nil {
            performSegue(withIdentifier: "checkToLogin", sender: self)
        } else {
            performSegue(withIdentifier: "checkToSignup", sender: self)
        }
    }
}
