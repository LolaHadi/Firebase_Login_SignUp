//
//  SignupPhoneViewController.swift
//  MfirstFirebase
//
//  Created by Lola M on 12/6/21.
//

import UIKit

class SignupPhoneViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()


    }

}
