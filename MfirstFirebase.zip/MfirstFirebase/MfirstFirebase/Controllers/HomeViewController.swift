//
//  HomeViewController.swift
//  MfirstFirebase
//
//  Created by Lola M on 12/6/21.
//

import UIKit
import Firebase

class HomeViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    @IBAction func SignoutBtnAction(_ sender: Any) {
        
        do {
            try Auth.auth().signOut()
            dismiss(animated: true, completion: nil)
        } catch {
            print(error)
        }
   }
    
}
